﻿#pragma strict
var numAtmo : UILabel;
var numLand : UILabel;
var numBact : UILabel;
var numOrga : UILabel;
var numPlants : UILabel;
var numAnim : UILabel;
var numHumans : UILabel;
var numProp : UILabel;
var numTemples : UILabel;
var spirit : UILabel;

var timer : float = 5;

function Start()
{

if(!PlayerPrefs.GetFloat("FirstTimeSaving"))
{
	PlayerPrefs.SetFloat("FirstTimeSaving",1);
	Application.LoadLevel("Splash");
	
}
}


function OnClick () {

SaveSettings();

}

function Update() {


if (timer<Time.deltaTime) {
	SaveSettings();
	timer=5;
}
else
	timer = timer-Time.deltaTime;
	
}

function SaveSettings() {

	Debug.Log("Progress saved.");
	PlayerPrefs.SetFloat("SpiritPerTick",addSpirit.spiritPerTick);
	PlayerPrefs.SetFloat("Spirit",addSpirit.spirit);
	PlayerPrefs.SetFloat("Atmo",parseFloat(numAtmo.text));
	PlayerPrefs.SetFloat("Land",parseFloat(numLand.text));
	PlayerPrefs.SetFloat("Bact",parseFloat(numBact.text));
	PlayerPrefs.SetFloat("Orga",parseFloat(numOrga.text));
	PlayerPrefs.SetFloat("Plants",parseFloat(numPlants.text));
	PlayerPrefs.SetFloat("Anim",parseFloat(numAnim.text));
	PlayerPrefs.SetFloat("Humans",parseFloat(numHumans.text));
	PlayerPrefs.SetFloat("Prop",parseFloat(numProp.text));
	PlayerPrefs.SetFloat("Temples",parseFloat(numTemples.text));
	PlayerPrefs.Save();
	
	
	
	if(parseInt(numTemples.text)>0)
	{
		Application.ExternalCall("kongregate.stats.submit","Number of Temples",parseInt(numTemples.text));
	}
	}