﻿#pragma strict

static var spiritTimer : double = 0.0f;
static var spiritPerTick : double = 1.0f;
static var spirit : double = 5.0f;
static var spiritLabel : UILabel;

function Start () {
spiritLabel = GameObject.Find("currentSpirit").GetComponent("UILabel");
Application.runInBackground = true;

}

function FixedUpdate () {
if (
spiritPerTick<1){spiritPerTick=1;
}
	
	spiritTimer += Time.deltaTime;
	if (spiritTimer >= .1)
	{
		// do stuff
		spirit = spirit + (spiritPerTick/3);
		spiritLabel.text = Mathf.Round(spirit).ToString("n0");
		spiritTimer = 0;
/*
		this.particleSystem.emissionRate = (spirit/100)+1;
		this.particleSystem.startSpeed = (spirit/1000)+1;
		this.particleSystem.startLifetime = (spirit/50000)+1;

		if (spirit > 10000) {
		this.particleSystem.emissionRate = 100;
		}
		
		
		if (spirit > 100000) {
		this.particleSystem.startSpeed = 100;
		}
		
		if (spirit > 300000) {
		this.particleSystem.startLifetime = 6;
		}
		*/
		
	}
}
