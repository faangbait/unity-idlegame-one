﻿#pragma strict

function OnClick(){
PlayerPrefs.DeleteAll();
Application.LoadLevel("Opening Scene");
}