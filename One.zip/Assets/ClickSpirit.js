﻿#pragma strict

function Start () {

}

function OnClick () {
	addSpirit.spirit = addSpirit.spirit + 1;
}