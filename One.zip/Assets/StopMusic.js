﻿#pragma strict
var BackgroundAudio : GameObject;
var MusicPlaying : boolean = true;

function OnClick() {

switch(MusicPlaying){

	case false:BackgroundAudio.audio.Play();
	MusicPlaying = true;
	break;

	case true:BackgroundAudio.audio.Stop();
	MusicPlaying=false;
	break;
}
}