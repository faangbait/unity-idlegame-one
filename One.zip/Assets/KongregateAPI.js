﻿//SUBMIT STATISTICS WITH
// Application.ExternalCall("kongregate.stats.submit","MatchesMade",1);

var isKongregate = false;
var userId = 0;
static var username = "Guest";
var gameAuthToken = "";

function OnKongregateAPILoaded(userInfoString){
//This is Kong
isKongregate = true;
Debug.Log("ON KONG");

//Split user info into tokens
var params = userInfoString.Split("|"[0]);
userId = parseInt(params[0]);
username=params[1];
gameAuthToken = params[2];
}

function Awake()
{
DontDestroyOnLoad (this);
Application.ExternalEval("if(typeof(kongregateUnitySupport) != 'undefined'){" + " kongregateUnitySupport.initAPI('KongregateAPI', 'OnKongregateAPILoaded');" + "}"
);
}