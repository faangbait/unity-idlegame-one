﻿#pragma strict

function OnClick() {
Application.LoadLevel("Opening Scene");
}