﻿#pragma strict
var chatBox : UILabel;
var spiritBoost : boolean;
var timer : float = 0.2;

function FixedUpdate() {
if (spiritBoost){
	if (timer<=0){
 		addSpirit.spirit = addSpirit.spirit + (addSpirit.spiritPerTick/2);
		chatBox.text="Currently earning " + (addSpirit.spiritPerTick+(addSpirit.spiritPerTick/2*8)).ToString("n1") + " spirit per parsec!";
		timer=0.2;
	}
	else
	{
	timer-=Time.deltaTime;
	}
}
}

function OnHover(isOver) {
 if (isOver) {
	spiritBoost=true;
}
else
	{
	chatBox.text="Currently earning " + (addSpirit.spiritPerTick*3).ToString("n1") + " spirit per parsec";
	spiritBoost=false;
	}
}

